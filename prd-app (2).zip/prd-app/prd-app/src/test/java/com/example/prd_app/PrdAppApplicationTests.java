package com.example.prd_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrdAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
