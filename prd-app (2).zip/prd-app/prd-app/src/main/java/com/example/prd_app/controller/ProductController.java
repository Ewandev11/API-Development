package com.example.prd_app.controller;

import com.example.prd_app.data.Product;
import com.example.prd_app.exception.ProductAlreadyExistsException; // Import the custom exception
import com.example.prd_app.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.NoSuchElementException; //Imported relevant

@RestController
public class ProductController {
    @Autowired
    private ProductService productService;

    @GetMapping(path = "/products")
    public List<Product> findAllProducts() {
        return productService.getProducts();
    }

    @GetMapping(path = "/products/{id}")
    public Product findProductById(@PathVariable int id) {
        return productService.getProductById(id);
    }

    @GetMapping(path = "/products", params = "name")
    public List<Product> findProductByName(@RequestParam String name) {
        return productService.findProductByName(name);
    }

    @GetMapping(path = "/products", params = "price")
    public List<Product> findProductByPrice(@RequestParam int price) {
        return productService.findProductByPrice(price);
    }

    @GetMapping(path = "/products", params = "quantity")
    public List<Product> findProductByQuantity(@RequestParam int quantity) {
        return productService.findProductByQuantity(quantity);
    }

    @PostMapping(path = "/products")
    public ResponseEntity<String> createProduct(@RequestBody Product product) {
        try {
            // Call the ProductService createProduct method which now returns a string
            String message = productService.createProduct(product);
            return new ResponseEntity<>(message, HttpStatus.OK);
        } catch (ProductAlreadyExistsException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
        }
    }

    @PutMapping(path = "/products")
    public ResponseEntity<?> updateProduct(@RequestBody Product product) {
        try {
            Product updatedProduct = productService.updateProduct(product);
            return new ResponseEntity<>(updatedProduct, HttpStatus.OK);
        } catch (ProductAlreadyExistsException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
        }
    }

    //Endpoint to update the quantity of product
    @PutMapping("/products/update/quantity")
    public ResponseEntity<String> updateProductQuantity(@RequestParam int id, @RequestParam int quantity) {
        try {
            // Call the updated service method which returns a String message
            String message = productService.updateProductQuantity(id, quantity);
            return new ResponseEntity<>(message, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>("Product not found", HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    // Endpoint to update product availability
    @PutMapping("/products/update/availability")
    public ResponseEntity<String> updateProductAvailability(@RequestParam int id, @RequestParam String availability) {
        try {
            String message = productService.updateProductAvailability(id, availability);
            return new ResponseEntity<>(message, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>("Product not found", HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping(path = "/products/{id}")
    public ResponseEntity<String> deleteProduct(@PathVariable int id) {
        Product product = productService.deleteProductById(id);
        if (product != null) {
            return new ResponseEntity<>("Product Deleted Successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Product Not Found", HttpStatus.NOT_FOUND);
        }
    }
}
