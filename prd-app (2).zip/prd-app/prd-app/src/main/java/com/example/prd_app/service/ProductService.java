package com.example.prd_app.service;

import com.example.prd_app.data.Product;
import com.example.prd_app.data.ProductRepository;
import com.example.prd_app.exception.ProductAlreadyExistsException; // Import the custom exception
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.NoSuchElementException;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;

    public List<Product> getProducts() {
        return productRepository.findAll();
    }

    public Product getProductById(int id) {
        Optional<Product> product = productRepository.findById(id);
        return product.orElse(null);
    }

    public String createProduct(Product product) {
        // Check if a product with the same ID exists
        if (productRepository.existsById(product.getId())) {
            throw new ProductAlreadyExistsException("Product with ID " + product.getId() + " already exists.");
        }

        // Check if a product with the same name exists
        if (!productRepository.findByName(product.getName()).isEmpty()) {
            throw new ProductAlreadyExistsException("Product with name " + product.getName() + " already exists.");
        }

        productRepository.save(product);    // Save the new product
        return "Product added successfully"; // Return success message
    }

    public Product updateProduct(Product product) {
        // Check if a product with the same name exists (but not the same product)
        List<Product> productsWithName = productRepository.findProductByName(product.getName());
        if (!productsWithName.isEmpty() && productsWithName.get(0).getId() != product.getId()) {
            throw new ProductAlreadyExistsException("Product with name " + product.getName() + " already exists.");
        }

        return productRepository.save(product);
    }

    public List<Product> findProductByName(String name) {
        return productRepository.findProductByName(name);
    }

    public List<Product> findProductByPrice(int price) {
        return productRepository.findProductByPrice(price);
    }

    public List<Product> findProductByQuantity(int quantity) {
        return productRepository.findProductByQuantity(quantity);
    }

    public String updateProductQuantity(int id, int quantity) {
        // Find the product by ID or throw an exception if not found
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Product not found"));
        // Update the quantity and save the product
        product.setQuantity(quantity);
        productRepository.save(product); // Saving the updated product quantity

        return "Quantity has been updated successfully!";
    }

    public String updateProductAvailability(int id, String availability) {
        // Find the product by ID or throw an exception if not found
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Product not found"));
        // Update the availability and save the product
        product.setAvailability(availability);
        productRepository.save(product); // Save the updated product availability

        return "Availability status has been updated successfully!";
    }

    public Product deleteProductById(int id) {
        Optional<Product> product = productRepository.findById(id);
        if (product.isPresent()) {
            productRepository.deleteById(id);
            return product.get();
        }
        return null;
    }
}
