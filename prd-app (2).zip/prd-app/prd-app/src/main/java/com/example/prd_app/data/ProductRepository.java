package com.example.prd_app.data;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {

    @Query("select u from Product u where u.name = ?1")
    List<Product> findProductByName(String name);

    @Query("select u from Product u where u.price = ?1")
    List<Product> findProductByPrice(int price);

    @Query("select u from Product u where u.quantity = ?1")
    List<Product> findProductByQuantity(int quantity);

    // New method to find a product by name (to check for duplicates)
    Optional<Product> findByName(String name);

    // New method to check if a product with a specific ID exists (optional, as JpaRepository already has existsById)
    boolean existsById(int id);

    // New method to check if a product with a specific name exists
    boolean existsByName(String name);

}
